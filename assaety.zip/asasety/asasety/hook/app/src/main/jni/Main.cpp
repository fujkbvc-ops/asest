#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"
#include "KittyMemory/MemoryPatch.h"
//Target lib here
#define targetLibName OBFUSCATE("libUE4.so")
#define targetLibName OBFUSCATE("libanort.so")
#define targetLibName OBFUSCATE("libanogs.so")

#include "Includes/Macros.h"
//------------HOOKS
/*
__int64_t (*osub_12BA2C)(const char* a1, unsigned int a2);
__int64_t hsub_12BA2C(const char* a1, unsigned int a2) {
    sleep(9999999);
    return osub_12BA2C(a1, a2);
}
void * crashfix_thread(void *) {
       do {
        
} while (!isLibraryLoaded("libanort.so"));
HOOK_LIB("libanort.so","0x12BA2C",hsub_12BA2C,osub_12BA2C);//Fix Crash

 return NULL;
}
*/
void * hack_thread(void *) {
    LOGI(OBFUSCATE("RISING STARS LIBRARY READY...."));

    do {
        sleep(1);
    } while (!isLibraryLoaded(targetLibName));
PATCH_LIB("libanogs.so", "0x1ACA95", "4D 82 8A 53 49 1D 96 98 5C 38 1C 40 A3 1D 98 EF"); // bytes_strength=3200 offset_strength=96
PATCH_LIB("libanogs.so", "0x330C97", "CA 2B AF 76 D1 7F 09 B2 7B 6F 14 BF"); // bytes_strength=2400 offset_strength=92
PATCH_LIB("libanogs.so", "0xC16086", "0F 04 CF 0F F3 C5 FA 94 28 0F 47 70 30 D8"); // bytes_strength=2800 offset_strength=94
PATCH_LIB("libanogs.so", "0x34AB42", "41 C6 F7 8C B7 1B 88 C4 E8 00"); // bytes_strength=2000 offset_strength=94
PATCH_LIB("libanogs.so", "0x6EC528", "AA 7F F8 99 9F ED B0 98 3B BA BB"); // bytes_strength=2200 offset_strength=100
PATCH_LIB("libanogs.so", "0x72093F", "75 4B E1 18 35 D4 30 F1 86 BC 45 AF"); // bytes_strength=2400 offset_strength=92
PATCH_LIB("libanogs.so", "0x5C4873", "D1 A9 BB 75 FD E2 F1 4F 2C 34 3B 0B 38 24 C1 C6"); // bytes_strength=3200 offset_strength=93
PATCH_LIB("libanogs.so", "0xE269BF", "1E 38 08 C7 0C E0 F2 F0 3A"); // bytes_strength=1800 offset_strength=94
PATCH_LIB("libanogs.so", "0x560C6E", "76 2B E5 DA 20 25 B0 3B D8 CC 55"); // bytes_strength=2200 offset_strength=96
PATCH_LIB("libanogs.so", "0xDA3D77", "A1 66 1D 52 48 59 76 53 57 B8 B8 EA AD"); // bytes_strength=2600 offset_strength=92
PATCH_LIB("libanogs.so", "0x788AB6", "AB A5 CD 56 59 87 8F 50 18 F8 A1 35 2F 3F"); // bytes_strength=2800 offset_strength=90
PATCH_LIB("libanogs.so", "0x2A1415", "B0 E6 93 C1 77 F9 11 81 0A A0 65 C8 53 2D 79"); // bytes_strength=3000 offset_strength=98
PATCH_LIB("libanogs.so", "0x2AC793", "7F 55 5A 2F 59 B6 0D EE 02"); // bytes_strength=1800 offset_strength=98
PATCH_LIB("libanogs.so", "0x80498E", "04 ED C0 E0 F0 E5 5E 26 21 13 B6 44 8B A4 15"); // bytes_strength=3000 offset_strength=94
PATCH_LIB("libanogs.so", "0xF075AE", "5E 4A 8E 2B 8F FE 0F 69 7E 9A C6 5A B7 18 B3 03"); // bytes_strength=3200 offset_strength=100
PATCH_LIB("libanogs.so", "0xE0228C", "7B E9 12 83 97 8E 17 4B 1D 59 78 5D 15"); // bytes_strength=2600 offset_strength=98
PATCH_LIB("libanogs.so", "0x880363", "C9 5D C6 BD C2 12 8E 32 1F 7A FE C0 37"); // bytes_strength=2600 offset_strength=97
PATCH_LIB("libanogs.so", "0xF2BE7B", "36 09 B3 B3 7F E8 75 DF A7 39 2C E2 21 40"); // bytes_strength=2800 offset_strength=96
PATCH_LIB("libanogs.so", "0x3D7DE7", "A5 1B 3E 2F 25 DE 6B 84 EA 19 10 0E 8B 8F 9C 86"); // bytes_strength=3200 offset_strength=97
PATCH_LIB("libanogs.so", "0x9A6B9C", "BD 61 B1 A1 0F F9 B1 2E 16"); // bytes_strength=1800 offset_strength=90
PATCH_LIB("libanogs.so", "0xAF05BF", "57 35 9C 0F EA E3 40 B7 77"); // bytes_strength=1800 offset_strength=93
PATCH_LIB("libanogs.so", "0xF226BC", "E1 78 F5 EC 8D 38 F6 FE FF 7C 42 E2 CF 84 1A F6"); // bytes_strength=3200 offset_strength=95
PATCH_LIB("libanogs.so", "0x6454B1", "B2 44 77 F3 6F 4C FB 93 7F AC C2"); // bytes_strength=2200 offset_strength=94
PATCH_LIB("libanogs.so", "0xA6349D", "19 17 4B 50 4C D6 4A E7 D9 DF 5C"); // bytes_strength=2200 offset_strength=90
PATCH_LIB("libanogs.so", "0x7F7E20", "A0 E7 BF 8E 34 87 C9 FA AA 4A A2 BB 7D CE 96 2F"); // bytes_strength=3200 offset_strength=94
PATCH_LIB("libanogs.so", "0x566BAF", "F7 5C 44 88 5C 8B 73 FA F7 13 06 7A 2F 38"); // bytes_strength=2800 offset_strength=96
PATCH_LIB("libanogs.so", "0x797364", "2A E7 41 5D D1 68 0B 41 87 EF A8"); // bytes_strength=2200 offset_strength=94
PATCH_LIB("libanogs.so", "0x27AA82", "41 39 C5 2A EF 5F 2C 38 54 EA 46 13 40"); // bytes_strength=2600 offset_strength=93
PATCH_LIB("libanogs.so", "0x9512DF", "E1 8A E9 3F 21 07 64 74 3E"); // bytes_strength=1800 offset_strength=90
PATCH_LIB("libanogs.so", "0xE11438", "E2 7D DD 71 37 00 5D 29 87 7E C9"); // bytes_strength=2200 offset_strength=95
PATCH_LIB("libanogs.so", "0x66D26F", "97 76 F0 F3 DD D9 46 C4 34 6A 68 70 1A 73 4B 87"); // bytes_strength=3200 offset_strength=96
PATCH_LIB("libanogs.so", "0x38ACA6", "3C 9D 63 F0 79 93 8C 37 3F"); // bytes_strength=1800 offset_strength=94
PATCH_LIB("libanogs.so", "0x56333F", "99 12 BE 70 8D 4D 62 E1 A6 6F"); // bytes_strength=2000 offset_strength=95
PATCH_LIB("libanogs.so", "0xE2D2B8", "60 3C 4E 83 CF E5 D6 BB F7 5E 6A D4 F7"); // bytes_strength=2600 offset_strength=95
PATCH_LIB("libanogs.so", "0xFE2328", "FF B4 CF 75 B9 3B 40 62 C0 5B"); // bytes_strength=2000 offset_strength=96
PATCH_LIB("libanogs.so", "0xE4EF5F", "72 8B 09 79 03 7B 03 CF 89 D2 58 8C"); // bytes_strength=2400 offset_strength=94
PATCH_LIB("libanogs.so", "0x101354", "3D B7 01 7A 77 64 57 D6 02 32 7F C2"); // bytes_strength=2400 offset_strength=98
PATCH_LIB("libanogs.so", "0xFB415B", "92 E8 10 60 A3 89 E3 E2 16 66 16 65 38"); // bytes_strength=2600 offset_strength=92
PATCH_LIB("libanogs.so", "0x643E11", "DF 21 E4 A6 3B 18 FB 5D 61 31 FE E4 59 C2 E2"); // bytes_strength=3000 offset_strength=100
PATCH_LIB("libanogs.so", "0x6516DA", "C7 2A 1C 69 E6 1A F1 2D"); // bytes_strength=1600 offset_strength=93
PATCH_LIB("libanogs.so", "0xA88087", "05 75 B2 90 B2 91 E8 F7"); // bytes_strength=1600 offset_strength=100
PATCH_LIB("libanogs.so", "0x3AEE96", "9F E9 0D 7A 6F 68 F8 7E 00 77 9F 75 34 C1 AA 0F"); // bytes_strength=3200 offset_strength=90
PATCH_LIB("libanogs.so", "0x237B81", "F4 67 3F EA 5D CE B5 10 F7 8D 76 01 2D"); // bytes_strength=2600 offset_strength=95
PATCH_LIB("libanogs.so", "0x13EED3", "89 49 F9 17 A4 54 3B 71 07 70 51 D6 2E 8D AB 3B"); // bytes_strength=3200 offset_strength=93
PATCH_LIB("libanogs.so", "0x9BEDE0", "F0 0C 40 96 65 E7 03 60"); // bytes_strength=1600 offset_strength=93
PATCH_LIB("libanogs.so", "0xC10DFD", "C4 06 B7 7B CF C5 F2 4C 8D 54 E8 0B 54 1E 5C"); // bytes_strength=3000 offset_strength=94
PATCH_LIB("libanogs.so", "0x982281", "B3 AC E0 73 71 B3 F9 05 5D 61 5F 2A B7 BB C2"); // bytes_strength=3000 offset_strength=90
PATCH_LIB("libanogs.so", "0xAADFCF", "C8 B5 7D 76 64 D3 56 9F"); // bytes_strength=1600 offset_strength=95
PATCH_LIB("libanogs.so", "0xA24211", "81 60 07 E5 E8 7E 2C 18 15 F1 21 97 9C D3 47 45"); // bytes_strength=3200 offset_strength=97
PATCH_LIB("libanogs.so", "0x50C3D5", "F0 0E 3E BB 43 34 89 17 B1 C9 09 A6 A7"); // bytes_strength=2600 offset_strength=98
PATCH_LIB("libanogs.so", "0xB5877C", "5D 78 47 84 0F 0F B4 A3 E3 71 A6 B7 F2 9A 20"); // bytes_strength=3000 offset_strength=92
PATCH_LIB("libanogs.so", "0xE49B8C", "54 D7 BF EC 36 EC 6A 4D B8 E4 16"); // bytes_strength=2200 offset_strength=99
PATCH_LIB("libanogs.so", "0x8E4C1A", "C5 F9 FE F2 39 F9 90 FE 0E B0 78 AC"); // bytes_strength=2400 offset_strength=96
PATCH_LIB("libanogs.so", "0x62C954", "27 CF 65 AC 45 68 48 30 71 28 64"); // bytes_strength=2200 offset_strength=97
PATCH_LIB("libanogs.so", "0xCBA8A8", "AB 6C 2D C0 DE F8 EF 03 FA"); // bytes_strength=1800 offset_strength=90
PATCH_LIB("libanogs.so", "0x21766F", "EA 30 CB 2F 7A 30 E2 E9 5C"); // bytes_strength=1800 offset_strength=90
PATCH_LIB("libanogs.so", "0x7E806A", "CE 6A E5 87 12 93 2A 51 DE 55 B7 E2 79 58 BC"); // bytes_strength=3000 offset_strength=90
PATCH_LIB("libanogs.so", "0xA94E55", "F0 2E 40 54 D2 E6 75 71 78 4D"); // bytes_strength=2000 offset_strength=99
PATCH_LIB("libanogs.so", "0x6B2753", "53 DB 79 23 ED D2 75 0A DF"); // bytes_strength=1800 offset_strength=98
PATCH_LIB("libanogs.so", "0xF224E5", "D6 28 64 21 D0 D8 64 C1 12 E3 A4 12"); // bytes_strength=2400 offset_strength=97
PATCH_LIB("libanogs.so", "0xB03AE8", "73 8E 47 57 F2 80 8A AE CA"); // bytes_strength=1800 offset_strength=90
PATCH_LIB("libanogs.so", "0xC90553", "55 97 5D F0 45 0A F2 D3 59 49 92 43 FC 5E 5C 91"); // bytes_strength=3200 offset_strength=90
PATCH_LIB("libanogs.so", "0x660D69", "68 22 D1 44 C0 E6 05 34 C8 3F A4 1E 02 0A"); // bytes_strength=2800 offset_strength=96
PATCH_LIB("libanogs.so", "0xE120A3", "06 65 32 A8 1F 08 5D 04"); // bytes_strength=1600 offset_strength=96
PATCH_LIB("libanogs.so", "0x4319BD", "E1 79 DD 8C E5 1C 2D 19"); // bytes_strength=1600 offset_strength=91
PATCH_LIB("libanogs.so", "0xA6C7BB", "D9 F4 14 23 68 33 0E 49 03 CD 65 82 A9 CC FC"); // bytes_strength=3000 offset_strength=93
PATCH_LIB("libanogs.so", "0x7AE860", "A1 3A A7 06 A4 6C 26 46 40 18 8D 59 AA A3 DD"); // bytes_strength=3000 offset_strength=100
PATCH_LIB("libanogs.so", "0x2E8527", "DC 74 29 68 A7 55 9F C6 2F D0 53 14 A9 00 C5"); // bytes_strength=3000 offset_strength=100
PATCH_LIB("libanogs.so", "0x4F7D0D", "A4 C0 BF 6C F6 44 6F 80"); // bytes_strength=1600 offset_strength=100
PATCH_LIB("libanogs.so", "0x8919F9", "A0 59 E1 D7 D0 99 A0 8C 85 FA 04 92 C8 D3"); // bytes_strength=2800 offset_strength=92
PATCH_LIB("libanogs.so", "0x95A14A", "DC 78 AE 21 E7 83 EB 14 04 7B 0D 93"); // bytes_strength=2400 offset_strength=100
PATCH_LIB("libanogs.so", "0x1763BD", "3F 3B 63 C2 84 9C 90 31 D5 E7 40 E7 EA C4 B9 CE"); // bytes_strength=3200 offset_strength=92
PATCH_LIB("libanogs.so", "0xFAA2C4", "0D 9B E4 09 73 86 9A 69 D0 ED 9B E7 22 2B 72"); // bytes_strength=3000 offset_strength=92
PATCH_LIB("libanogs.so", "0xB458ED", "1C 1D 82 7B 90 4A 6C 1A 77 B4 24 79 49 C4"); // bytes_strength=2800 offset_strength=90
PATCH_LIB("libanogs.so", "0x7F6A24", "7D 9F 71 F8 F3 08 C8 AB 84 7B 19 52 7D 8B 68 83"); // bytes_strength=3200 offset_strength=94
PATCH_LIB("libanogs.so", "0xF36B9F", "15 29 9B 13 D7 23 84 FC 3D 51"); // bytes_strength=2000 offset_strength=90
PATCH_LIB("libanogs.so", "0x7A08D8", "6B C1 15 F4 31 99 3F D1 90 4F 4C 3F 53"); // bytes_strength=2600 offset_strength=98
PATCH_LIB("libanogs.so", "0x6478FF", "43 70 16 B4 8A 3E 1B 55 3F"); // bytes_strength=1800 offset_strength=90
PATCH_LIB("libanogs.so", "0x9C79A4", "C9 28 77 FC 18 65 64 96 4C"); // bytes_strength=1800 offset_strength=93
PATCH_LIB("libanogs.so", "0xE83025", "00 80 F7 83 04 F0 0D 65 D7"); // bytes_strength=1800 offset_strength=96
PATCH_LIB("libanogs.so", "0x673EEF", "0E 9C B0 2B 6E 32 75 3A 9A 36 51 5C 67 81 B1 83"); // bytes_strength=3200 offset_strength=91
PATCH_LIB("libanogs.so", "0x23B668", "B7 D5 C1 EB 6E AF 2B 62 35 59 C0"); // bytes_strength=2200 offset_strength=99
PATCH_LIB("libanogs.so", "0x3DD57B", "8A D3 26 C2 7A FB 53 F6 73 3A 95 B7 03 78"); // bytes_strength=2800 offset_strength=91
PATCH_LIB("libanogs.so", "0x965838", "8D 63 1C 49 61 13 52 E1 3B 29 B7 37 CC F2"); // bytes_strength=2800 offset_strength=97
PATCH_LIB("libanogs.so", "0x354E56", "B6 B0 29 DC A9 AF AE 88 99 75 04 2E"); // bytes_strength=2400 offset_strength=99
PATCH_LIB("libanogs.so", "0x682B12", "C0 13 90 85 F0 61 DA EC 77 A8 BC EC 6A 47 7D"); // bytes_strength=3000 offset_strength=100
PATCH_LIB("libanogs.so", "0x5AC249", "B4 AA 1B 6D 1E ED 4C A0 47"); // bytes_strength=1800 offset_strength=92
PATCH_LIB("libanogs.so", "0x84A5A8", "F3 FD A9 BE B0 5F 5C 07 9A 8C 94 1B 1F D5 F6"); // bytes_strength=3000 offset_strength=98
PATCH_LIB("libanogs.so", "0x83F869", "79 D6 4B 6B B6 D7 2B 2C EC 87 30 23"); // bytes_strength=2400 offset_strength=92
PATCH_LIB("libanogs.so", "0x646FCA", "F3 B6 37 B8 4E 5B 77 D8 9A 96 60 92 FA"); // bytes_strength=2600 offset_strength=98
PATCH_LIB("libanogs.so", "0xFDB744", "1D 86 28 5C 85 D1 0D 31 33 B7 C0 1C"); // bytes_strength=2400 offset_strength=92
PATCH_LIB("libanogs.so", "0xEE4E8D", "C6 44 85 19 10 65 32 4C 1E F5 02"); // bytes_strength=2200 offset_strength=91
PATCH_LIB("libanogs.so", "0x57FC56", "C3 95 95 A3 D8 A4 F0 08 5E 63 82 B4 0A F0"); // bytes_strength=2800 offset_strength=92
PATCH_LIB("libanogs.so", "0x490E72", "DF 23 8A 64 84 25 91 41 AE 8E 60 A0"); // bytes_strength=2400 offset_strength=94
PATCH_LIB("libanogs.so", "0x59FC98", "0D DE FF F0 51 96 67 11 A3 68 F8 AB F5 6F 0B FF"); // bytes_strength=3200 offset_strength=100
PATCH_LIB("libanogs.so", "0xCC5B33", "F8 B7 8E 64 AD D2 04 27 A5 78 4B D0 E1 78"); // bytes_strength=2800 offset_strength=100
PATCH_LIB("libanogs.so", "0xD4DB86", "1A 6C 29 93 9C 53 29 5D 6C 2F"); // bytes_strength=2000 offset_strength=95
PATCH_LIB("libanogs.so", "0x3538F9", "F2 F3 4C 1B 4E C6 C8 8D DD 47 40 68 51 42"); // bytes_strength=2800 offset_strength=91
PATCH_LIB("libanogs.so", "0x79C8D5", "B4 8C ED 9C 52 2C 9C E7 1B"); // bytes_strength=1800 offset_strength=93
PATCH_LIB("libanogs.so", "0xAB4E25", "C8 B5 F4 7F ED 4A 16 41 1A 22 2B C1"); // bytes_strength=2400 offset_strength=95
PATCH_LIB("libanogs.so", "0xDFDCE5", "56 50 91 C7 B5 72 95 D7 BB"); // bytes_strength=1800 offset_strength=95
PATCH_LIB("libanogs.so", "0x641440", "1A B1 33 2C AA 20 10 D2 61 E8 21 7B 7B CF"); // bytes_strength=2800 offset_strength=98
PATCH_LIB("libanogs.so", "0x90647D", "68 E3 43 99 E0 2C 97 62 69 47 7E"); // bytes_strength=2200 offset_strength=99
PATCH_LIB("libanogs.so", "0x8B7778", "29 9F 74 7D 35 F1 43 C4 98 31 BD B4 C6 4F"); // bytes_strength=2800 offset_strength=100
PATCH_LIB("libanogs.so", "0x882300", "05 FF 7B F7 66 C6 DE C0 EA 1F 27 24 9C 4F A5"); // bytes_strength=3000 offset_strength=90
PATCH_LIB("libanogs.so", "0x525BF7", "03 82 5D B3 50 B8 C3 CB B5 C7"); // bytes_strength=2000 offset_strength=94
PATCH_LIB("libanogs.so", "0xDA3684", "E2 91 01 93 15 4A CF A3"); // bytes_strength=1600 offset_strength=97
PATCH_LIB("libanogs.so", "0x8A2E55", "6A FF A5 6C 48 D2 07 C0 78 0C"); // bytes_strength=2000 offset_strength=92
PATCH_LIB("libanogs.so", "0xBB4489", "3C A0 5C 96 3D BF AF 07 F2 D6 18 98 32 87 EA 50"); // bytes_strength=3200 offset_strength=98
PATCH_LIB("libanogs.so", "0xF443B9", "7F 1E DA A3 C0 57 21 C5 32 32 57 8C"); // bytes_strength=2400 offset_strength=100
PATCH_LIB("libanogs.so", "0x5CE7F1", "DE DC 2D 56 06 0B C7 C6"); // bytes_strength=1600 offset_strength=91
PATCH_LIB("libanogs.so", "0xFCD196", "FB BB 02 CA 52 03 D8 45"); // bytes_strength=1600 offset_strength=93
PATCH_LIB("libanogs.so", "0x8AF2EF", "FA 48 56 90 7F 2A 4B 8C ED"); // bytes_strength=1800 offset_strength=93
PATCH_LIB("libanogs.so", "0x8D1D88", "61 F6 C2 67 CE EC 74 55 AD"); // bytes_strength=1800 offset_strength=92
PATCH_LIB("libanogs.so", "0x2087D9", "0D 29 F0 6A 98 F9 97 D5 19 4B 83 62"); // bytes_strength=2400 offset_strength=95
PATCH_LIB("libanogs.so", "0x65B35D", "A9 A8 64 B2 B0 6F 58 17 B7 A6 19"); // bytes_strength=2200 offset_strength=90
PATCH_LIB("libanogs.so", "0x712E91", "6D 06 5D 29 7C 4A DA FA 01 13 5D 92"); // bytes_strength=2400 offset_strength=93
PATCH_LIB("libanogs.so", "0xE8D9FE", "B4 2A 8E 70 CC 8C 31 E5 B6 DD 1D F0 A5"); // bytes_strength=2600 offset_strength=90
PATCH_LIB("libanogs.so", "0xE57B79", "CE 58 32 4C 70 B6 3C 8F 37 1B 1B 4A"); // bytes_strength=2400 offset_strength=93
PATCH_LIB("libanogs.so", "0x778904", "E3 E6 09 2A 4C 8F 94 0F 66 EA 9A C0 27"); // bytes_strength=2600 offset_strength=92
PATCH_LIB("libanogs.so", "0x8D7D66", "8E 97 35 2C 3C 00 96 AB D5 17 93"); // bytes_strength=2200 offset_strength=91
PATCH_LIB("libanogs.so", "0xDADD95", "FB 2B 22 29 E6 B6 7E 63 EF D3 30 90 74"); // bytes_strength=2600 offset_strength=93
PATCH_LIB("libanogs.so", "0xEA7861", "99 3C A8 F3 32 0C 81 3A EC"); // bytes_strength=1800 offset_strength=91
PATCH_LIB("libanogs.so", "0xB6AF4F", "95 21 6A 0F E1 CB F0 44"); // bytes_strength=1600 offset_strength=100
PATCH_LIB("libanogs.so", "0x2D1486", "7B 7B DD 43 8A 50 F9 58 7D E1 14 83 40"); // bytes_strength=2600 offset_strength=90
PATCH_LIB("libanogs.so", "0xA9F8DA", "D1 A6 E6 FF FC 2A 11 4F"); // bytes_strength=1600 offset_strength=97
PATCH_LIB("libanogs.so", "0xCEF687", "AD C5 3A 3A 85 33 23 93 A5 E7"); // bytes_strength=2000 offset_strength=98
PATCH_LIB("libanogs.so", "0x2BE2EC", "1B EF 66 09 35 A2 86 8B"); // bytes_strength=1600 offset_strength=98
PATCH_LIB("libanogs.so", "0xFB76E7", "F6 63 FB FA 5B 31 7A 83 F1 85 71 3C 6E"); // bytes_strength=2600 offset_strength=96
PATCH_LIB("libanogs.so", "0xC5D3D2", "5E 52 6D DB A8 0F 3E DC B7 D3"); // bytes_strength=2000 offset_strength=97
PATCH_LIB("libanogs.so", "0xE10C79", "99 ED DD FB 42 5E 73 51 AF AD"); // bytes_strength=2000 offset_strength=95
PATCH_LIB("libanogs.so", "0x13DCC8", "A5 A3 1A B0 21 29 73 52"); // bytes_strength=1600 offset_strength=97
PATCH_LIB("libanogs.so", "0x71CBCB", "34 79 0C 47 A4 40 06 96 69 44 79 A5 99"); // bytes_strength=2600 offset_strength=90
PATCH_LIB("libanogs.so", "0x1D8278", "65 96 09 C3 62 41 C6 0D 16 28 4D 0F"); // bytes_strength=2400 offset_strength=91
PATCH_LIB("libanogs.so", "0xABE9AC", "83 55 BA B9 CF AC 98 1D 31 D0 87 62"); // bytes_strength=2400 offset_strength=99
PATCH_LIB("libanogs.so", "0x748BA2", "51 C5 DA FC 4A 51 9E 22 15 C4 66 68 E1 38 31 E6"); // bytes_strength=3200 offset_strength=98
PATCH_LIB("libanogs.so", "0x396AAF", "BA E9 8F 33 BB 1F 8E 86"); // bytes_strength=1600 offset_strength=98
PATCH_LIB("libanogs.so", "0x5130BB", "73 70 10 80 FF 37 9B DB 5A 08 22 FA"); // bytes_strength=2400 offset_strength=96
PATCH_LIB("libanogs.so", "0xC92644", "BB EA D1 96 1E 5D 89 84 AB 37 E8 CC 3F A4 41"); // bytes_strength=3000 offset_strength=96
PATCH_LIB("libanogs.so", "0x181408", "38 83 72 5B AE DF BD FD FF E4 E0 08 98 61"); // bytes_strength=2800 offset_strength=97
PATCH_LIB("libanogs.so", "0x2B7EC4", "85 63 60 06 8E CE B5 9F 38 D6 F4 2F CE 84"); // bytes_strength=2800 offset_strength=92
PATCH_LIB("libanogs.so", "0x4AF90F", "51 D4 9A BD 1F 93 49 16 29 33 0E AF 9B A4 5E"); // bytes_strength=3000 offset_strength=97
PATCH_LIB("libanogs.so", "0xF89553", "C0 1F 26 CE 6D 3F 9D 1D 80 FA E4 E0 30 A7"); // bytes_strength=2800 offset_strength=94
PATCH_LIB("libanogs.so", "0x2C6272", "C3 CB 45 97 E5 47 A5 E8 47 7D 1D 1E 7A E5 3A A1"); // bytes_strength=3200 offset_strength=100
PATCH_LIB("libanogs.so", "0x499152", "80 34 C0 45 CA E9 F0 94 9B 87 EC 79 42 01 B2"); // bytes_strength=3000 offset_strength=100
PATCH_LIB("libanogs.so", "0x726D59", "77 47 95 C2 CB 85 48 C7 7A 51 0D 70"); // bytes_strength=2400 offset_strength=92
PATCH_LIB("libanogs.so", "0x1A0C1F", "06 F0 23 9F 39 1A C7 3E C8"); // bytes_strength=1800 offset_strength=91
PATCH_LIB("libanogs.so", "0xE42F19", "12 5E 82 FE F5 A1 61 F3 8A F0 91 68 C1 73 54 BE"); // bytes_strength=3200 offset_strength=92
PATCH_LIB("libanogs.so", "0xAE00A7", "97 65 40 C4 11 60 6A 89 FE F0 5F E1 AD"); // bytes_strength=2600 offset_strength=94
PATCH_LIB("libanogs.so", "0x71A733", "DF 4F 1D CE 76 44 D6 AF C3 44"); // bytes_strength=2000 offset_strength=96
PATCH_LIB("libanogs.so", "0x1C1ED4", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x1C7FC8", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x1CA18C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x1D6EA8", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x1D7398", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x1D79A4", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x1D82CC", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x1FBD6C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x1FBD84", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x1FC69C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x202C38", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x203D2C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x203D40", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x203EEC", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x203F14", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x203F68", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x203FD4", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x20CE20", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x20CE34", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x20CE48", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x20CF74", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x20CF8C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x20CFA8", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x20D02C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x20D0B8", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x20D0D8", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x20D160", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x20D564", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x213B48", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x213B8C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x22552C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2272F8", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x227320", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x229B80", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x22A45C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x23F084", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x26A54C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x26A560", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x26A588", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x279158", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x27DAF8", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2BC510", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2C3D78", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2C3DF0", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2C3EFC", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2C42DC", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2C59F0", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2C5A08", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2C5C64", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2C5F00", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2C8B20", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2C8E10", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2C8FB4", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2C9024", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2C9148", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2C9934", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2CAC90", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2CAF00", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2CAF48", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2CB820", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2CBAA4", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2CC4D0", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2DC060", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2DD2B4", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2DD848", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2DDA64", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2DDA90", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2DDABC", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2DDAE8", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2DDB38", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2DDB64", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2DDC2C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2DDD64", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2DDD88", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2DF3F0", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2E20EC", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2E4A68", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2E7B2C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2F3EA4", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2F4BA8", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x2FE378", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x311E64", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x316D18", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x327844", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x327C34", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x32BFB8", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x33FF14", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x342578", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x361850", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x367A80", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x36EA18", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x370B94", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x3736B4", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x37670C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x378FE0", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x37AB68", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x37EF30", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x3874F0", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x3A0024", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x3ABB24", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x3AFF44", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x3B1854", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x3B1874", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x3B4164", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x3B5190", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x3B7860", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x3B7938", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x42F1E8", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x42FB84", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x42FC94", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x436E8C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x437C7C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x43C0B4", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x43E74C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x43EAD8", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4458E0", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x44F7D0", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x453CA4", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x45C710", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x461DC8", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4645A0", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x467948", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4684D4", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x46A9E4", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x46D5BC", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x478454", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4784E8", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x47862C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x47B5AC", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x48A010", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x48E080", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x48EE38", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x48EF6C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x48EF94", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x491150", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x493C54", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x493C94", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x493CD4", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x493D14", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x493D60", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x496B70", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x498958", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4989A0", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4B0CA4", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4B2F6C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4B37A8", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4B3804", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4B3F88", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4B3FAC", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4B3FD0", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4B3FF4", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4B4018", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4B403C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4B4060", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4B4084", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4B40A8", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4B40CC", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4B40F0", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4BF128", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4BF150", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4CAD10", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4CAFA0", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4CB0A4", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4CB3FC", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4CB568", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4CB88C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4CBD34", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4CC154", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4CC2C4", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4CE2B0", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4CE398", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4CE4AC", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4CF474", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4CF5CC", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4D0200", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4D0D18", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4D0F08", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4D1048", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4D1344", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4D1414", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4D153C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4D28E4", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4D28F8", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4D290C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4D2990", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4D4F4C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4D50BC", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4DC2CC", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4DEB68", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4DEBD0", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4DF150", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4DF188", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4DF1CC", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4DF268", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4DF2C4", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4DF2F4", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4E3630", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4E9638", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4EECE8", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4F1C28", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4F2C44", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4F2C78", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4F2DC8", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4F2E5C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4F2EF8", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4F3B38", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4F3B64", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4F3E0C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4F4D7C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4F506C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4F51F0", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4F557C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x4F77C8", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x500030", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x5001C0", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x5001F0", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x500214", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x500238", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x50F61C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x513E68", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x519B5C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x519CD8", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x51AAC8", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x51BF5C", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so", "0x51C780", "00 00 80 D2 C0 03 5F D6");



    return NULL;
}__attribute__((constructor))
void lib_main() {
    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
}
